package com.smartkids.ai.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.smartkids.ai.model.Subject
import com.smartkids.ai.ui.common.ComingSoonScreen
import com.smartkids.ai.ui.home.HomeScreen

object Destination {
    const val HOME = "home"
    const val GAMES = "games"
    const val TUTOR = "tutor"
    const val SUBJECT_ARG = "subjectId"
    const val SUBJECT = "subject/{$SUBJECT_ARG}"
    fun subject(subject: Subject) = "subject/${subject.id}"
}

@Composable
fun AppNavHost() {
    val navController = rememberNavController()
    val goBack: () -> Unit = { navController.popBackStack() }

    NavHost(navController = navController, startDestination = Destination.HOME) {
        composable(Destination.HOME) {
            HomeScreen(
                onSubjectClick = { navController.navigate(Destination.subject(it)) },
                onGamesClick = { navController.navigate(Destination.GAMES) },
                onTutorClick = { navController.navigate(Destination.TUTOR) },
            )
        }
        composable(
            route = Destination.SUBJECT,
            arguments = listOf(navArgument(Destination.SUBJECT_ARG) { type = NavType.StringType }),
        ) { entry ->
            val subject = Subject.fromId(entry.arguments?.getString(Destination.SUBJECT_ARG))
            if (subject != null) SubjectLearningScreen(subject = subject, onBack = goBack)
        }
        composable(Destination.GAMES) {
            ComingSoonScreen(emoji = "🎮", title = "Games", onBack = goBack)
        }
        composable(Destination.TUTOR) {
            ComingSoonScreen(emoji = "🦉", title = "Ask Buddy", onBack = goBack)
        }
    }
}

private data class LessonQuestion(
    val question: String,
    val options: List<String>,
    val answerIndex: Int,
    val explanation: String,
)

private data class LessonTopic(
    val title: String,
    val emoji: String,
    val explanation: String,
    val example: String,
    val question: LessonQuestion,
)

private fun topicsFor(subject: Subject, grade: Int): List<LessonTopic> = when (subject) {
    Subject.MATHS -> listOf(
        LessonTopic("Numbers", "🔢", "Numbers help us count objects. Count slowly and say each number once.", "There are 3 apples: 🍎 🍎 🍎", LessonQuestion("What comes after $grade?", listOf("${grade + 1}", "$grade", "${grade - 1}", "0"), 0, "The next number is one more: $grade + 1 = ${grade + 1}.")),
        LessonTopic("Addition", "➕", "Addition means putting groups together.", "2 + 3 = 5", LessonQuestion("What is 2 + 3?", listOf("4", "5", "6", "3"), 1, "Two objects plus three objects make five objects.")),
        LessonTopic("Subtraction", "➖", "Subtraction means taking away from a group.", "5 − 2 = 3", LessonQuestion("What is 5 − 2?", listOf("2", "4", "3", "7"), 2, "Start at five and take away two. Three remain.")),
        LessonTopic("Shapes", "🔺", "Shapes are all around us. A triangle has 3 sides and a square has 4 equal sides.", "Triangle 🔺  Circle ⚪  Square ◻️", LessonQuestion("How many sides does a triangle have?", listOf("2", "3", "4", "5"), 1, "A triangle always has three sides.")),
    )
    Subject.ENGLISH -> listOf(
        LessonTopic("Alphabet", "🔤", "The English alphabet has 26 letters. Letters can be uppercase or lowercase.", "A a · B b · C c", LessonQuestion("Which one is a vowel?", listOf("B", "C", "A", "D"), 2, "A is a vowel. The vowels are A, E, I, O and U.")),
        LessonTopic("Words", "📖", "A word is made from letters and has a meaning.", "CAT = C + A + T 🐱", LessonQuestion("Which word names an animal?", listOf("Book", "Cat", "Pen", "Cup"), 1, "Cat is the name of an animal.")),
        LessonTopic("Sentences", "✍️", "A sentence expresses a complete thought. Begin with a capital letter and end with punctuation.", "I like mangoes.", LessonQuestion("Which sentence is written correctly?", listOf("i am happy", "I am happy.", "i am happy.", "I am happy"), 1, "Start with a capital letter and use a full stop.")),
        LessonTopic("Opposite Words", "↔️", "Opposite words have contrasting meanings.", "Big ↔ Small · Hot ↔ Cold", LessonQuestion("What is the opposite of hot?", listOf("Warm", "Cold", "Fast", "Tall"), 1, "Cold is the opposite of hot.")),
    )
    Subject.SCIENCE -> listOf(
        LessonTopic("Living Things", "🌱", "Living things grow, need energy and respond to their surroundings.", "Plants, birds, humans and insects are living things.", LessonQuestion("Which one is a living thing?", listOf("Stone", "Chair", "Plant", "Pencil"), 2, "A plant grows and needs water, air and sunlight.")),
        LessonTopic("Our Body", "🫀", "Our body has many parts that work together. We keep it healthy with food, sleep and exercise.", "Eyes help us see; ears help us hear.", LessonQuestion("Which body part helps us hear?", listOf("Eyes", "Ears", "Nose", "Hands"), 1, "Our ears help us hear sounds.")),
        LessonTopic("Plants", "🌳", "Plants need sunlight, water, air and nutrients to grow.", "Root · Stem · Leaves · Flower", LessonQuestion("Which part usually absorbs water from soil?", listOf("Flower", "Leaf", "Root", "Fruit"), 2, "Roots take up water and help anchor the plant.")),
        LessonTopic("Space", "🌞", "Earth is the planet where we live. It moves around the Sun.", "Sun ☀️ · Earth 🌍 · Moon 🌙", LessonQuestion("Which star is closest to Earth?", listOf("Sun", "Sirius", "Polaris", "Vega"), 0, "The Sun is the star at the centre of our solar system.")),
    )
    Subject.MARATHI -> listOf(
        LessonTopic("स्वर", "अआइ", "स्वरांचा उच्चार स्वतंत्रपणे करता येतो.", "अ, आ, इ, ई, उ, ऊ, ए, ऐ, ओ, औ", LessonQuestion("'अ' हा कोणता वर्ण आहे?", listOf("स्वर", "व्यंजन", "अंक", "शब्द"), 0, "'अ' हा मराठीतील स्वर आहे.")),
        LessonTopic("व्यंजन", "कखग", "व्यंजनांचा उच्चार करताना स्वराची मदत लागते.", "क, ख, ग, घ, ङ", LessonQuestion("यापैकी व्यंजन कोणते?", listOf("आ", "ई", "क", "ओ"), 2, "'क' हे व्यंजन आहे.")),
        LessonTopic("शब्द", "📚", "अर्थ असलेल्या अक्षरांच्या समूहाला शब्द म्हणतात.", "कमळ, घर, आई, शाळा", LessonQuestion("यापैकी फुलाचे नाव कोणते?", listOf("घर", "कमळ", "पुस्तक", "रस्ता"), 1, "कमळ हे फुलाचे नाव आहे.")),
        LessonTopic("संख्या", "१ २ ३", "संख्या मोजण्यासाठी आणि प्रमाण सांगण्यासाठी वापरतात.", "एक, दोन, तीन, चार, पाच", LessonQuestion("तीननंतर कोणती संख्या येते?", listOf("दोन", "चार", "पाच", "एक"), 1, "तीननंतर चार येते.")),
    )
}

@Composable
private fun SubjectLearningScreen(subject: Subject, onBack: () -> Unit) {
    var grade by remember(subject) { mutableIntStateOf(1) }
    var selectedTopic by remember(subject) { mutableIntStateOf(-1) }
    var selectedAnswer by remember(subject) { mutableIntStateOf(-1) }
    var checked by remember(subject) { mutableStateOf(false) }
    val topics = topicsFor(subject, grade)

    Column(
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack) { Text("← Back") }
            Spacer(Modifier.weight(1f))
            Text(subject.emoji, fontSize = 30.sp)
        }
        Spacer(Modifier.height(12.dp))
        Text(subjectLabel(subject), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Learn step by step • Classes 1–5", style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            (1..5).forEach { classNo ->
                FilterChip(selected = grade == classNo, onClick = {
                    grade = classNo; selectedTopic = -1; selectedAnswer = -1; checked = false
                }, label = { Text("Class $classNo") })
            }
        }
        Spacer(Modifier.height(12.dp))
        if (selectedTopic == -1) {
            Text("Choose a lesson", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(topics) { topic ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable {
                            selectedTopic = topics.indexOf(topic); selectedAnswer = -1; checked = false
                        },
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = subject.color.copy(alpha = 0.16f)),
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(topic.emoji, fontSize = 34.sp)
                            Column(Modifier.padding(start = 14.dp).weight(1f)) {
                                Text(topic.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text("Read and try a question", style = MaterialTheme.typography.bodyMedium)
                            }
                            Text("›", fontSize = 30.sp)
                        }
                    }
                }
            }
        } else {
            val topic = topics[selectedTopic]
            LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = subject.color.copy(alpha = 0.15f))) {
                        Column(Modifier.padding(18.dp)) {
                            Text("${topic.emoji}  ${topic.title}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text(topic.explanation, style = MaterialTheme.typography.bodyLarge)
                            Spacer(Modifier.height(12.dp))
                            Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surface) {
                                Text("Example: ${topic.example}", modifier = Modifier.fillMaxWidth().padding(14.dp), style = MaterialTheme.typography.titleMedium)
                            }
                        }
                    }
                }
                item {
                    Text("Quick quiz", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(topic.question.question, style = MaterialTheme.typography.titleMedium)
                }
                items(topic.question.options.indices.toList()) { index ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { if (!checked) selectedAnswer = index },
                        colors = CardDefaults.cardColors(
                            containerColor = if (selectedAnswer == index) subject.color.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                        ),
                    ) {
                        Row(Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = selectedAnswer == index, onClick = { if (!checked) selectedAnswer = index }, enabled = !checked)
                            Text(topic.question.options[index], modifier = Modifier.padding(start = 6.dp))
                        }
                    }
                }
                if (checked) item {
                    Text(
                        text = (if (selectedAnswer == topic.question.answerIndex) "✅ Correct! " else "💡 Not quite. ") + topic.question.explanation,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                }
                item {
                    Button(onClick = {
                        if (checked) { selectedTopic = -1; selectedAnswer = -1; checked = false }
                        else if (selectedAnswer >= 0) checked = true
                    }, modifier = Modifier.fillMaxWidth(), enabled = checked || selectedAnswer >= 0) {
                        Text(if (checked) "All lessons" else "Check answer")
                    }
                    OutlinedButton(onClick = { selectedTopic = -1; selectedAnswer = -1; checked = false }, modifier = Modifier.fillMaxWidth()) {
                        Text("Choose another lesson")
                    }
                }
            }
        }
    }
}

private fun subjectLabel(subject: Subject): String = when (subject) {
    Subject.MATHS -> "Mathematics"
    Subject.ENGLISH -> "English"
    Subject.SCIENCE -> "Science"
    Subject.MARATHI -> "मराठी"
}
