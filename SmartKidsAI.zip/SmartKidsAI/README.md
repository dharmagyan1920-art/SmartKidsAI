# Smart Kids AI

Android app for students in classes 1-5 (India). Kotlin + Jetpack Compose + Material 3.

## Run
1. Android Studio Koala (2024.1.1) or newer, JDK 17 (bundled).
2. File > Open > select this folder, wait for Gradle sync.
3. Pick an emulator (API 24+) or a USB-debugging phone, press Run.

## Structure
- model/ - data types (Subject)
- navigation/ - routes and NavHost
- ui/theme/ - colours, typography, shapes
- ui/common/ - shared composables
- ui/home/ - home screen
