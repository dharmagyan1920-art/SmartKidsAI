package com.smartkids.ai.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.smartkids.ai.R
import com.smartkids.ai.model.Subject
import com.smartkids.ai.ui.common.ComingSoonScreen
import com.smartkids.ai.ui.home.HomeScreen

object Destination {
    const val HOME = "home"
    const val GAMES = "games"
    const val TUTOR = "tutor"

    const val SUBJECT_ARG = "subjectId"
    const val SUBJECT = "subject/{$SUBJECT_ARG}"

    fun subject(subject: Subject) = "subject/${subject.id}"
}

@Composable
fun AppNavHost() {
    val navController = rememberNavController()
    val goBack: () -> Unit = { navController.popBackStack() }

    NavHost(navController = navController, startDestination = Destination.HOME) {
        composable(Destination.HOME) {
            HomeScreen(
                onSubjectClick = { navController.navigate(Destination.subject(it)) },
                onGamesClick = { navController.navigate(Destination.GAMES) },
                onTutorClick = { navController.navigate(Destination.TUTOR) },
            )
        }

        composable(
            route = Destination.SUBJECT,
            arguments = listOf(navArgument(Destination.SUBJECT_ARG) { type = NavType.StringType }),
        ) { entry ->
            val subject = Subject.fromId(entry.arguments?.getString(Destination.SUBJECT_ARG))
            if (subject != null) {
                // TODO: replace with SubjectScreen (topics, quizzes) in the next step.
                ComingSoonScreen(
                    emoji = subject.emoji,
                    title = stringResource(subject.titleRes),
                    onBack = goBack,
                )
            }
        }

        composable(Destination.GAMES) {
            // TODO: replace with GamesScreen.
            ComingSoonScreen(
                emoji = "🎮",
                title = stringResource(R.string.games_title),
                onBack = goBack,
            )
        }

        composable(Destination.TUTOR) {
            // TODO: replace with AiTutorScreen (chat UI).
            ComingSoonScreen(
                emoji = "🦉",
                title = stringResource(R.string.tutor_title),
                onBack = goBack,
            )
        }
    }
}
