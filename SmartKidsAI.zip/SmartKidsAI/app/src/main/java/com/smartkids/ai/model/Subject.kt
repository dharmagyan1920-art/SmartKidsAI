package com.smartkids.ai.model

import androidx.annotation.StringRes
import androidx.compose.ui.graphics.Color
import com.smartkids.ai.R
import com.smartkids.ai.ui.theme.EnglishBlue
import com.smartkids.ai.ui.theme.MarathiPurple
import com.smartkids.ai.ui.theme.MathsOrange
import com.smartkids.ai.ui.theme.ScienceGreen

/** The four subjects offered in the app. [id] is used as the navigation argument. */
enum class Subject(
    val id: String,
    @StringRes val titleRes: Int,
    @StringRes val taglineRes: Int,
    val emoji: String,
    val color: Color,
) {
    MATHS("maths", R.string.subject_maths, R.string.subject_maths_tagline, "🔢", MathsOrange),
    ENGLISH("english", R.string.subject_english, R.string.subject_english_tagline, "📚", EnglishBlue),
    SCIENCE("science", R.string.subject_science, R.string.subject_science_tagline, "🔬", ScienceGreen),
    MARATHI("marathi", R.string.subject_marathi, R.string.subject_marathi_tagline, "🪔", MarathiPurple);

    companion object {
        fun fromId(id: String?): Subject? = entries.firstOrNull { it.id == id }
    }
}
