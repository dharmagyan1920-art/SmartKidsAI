package com.smartkids.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.smartkids.ai.navigation.AppNavHost
import com.smartkids.ai.ui.theme.SmartKidsTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SmartKidsTheme {
                AppNavHost()
            }
        }
    }
}
