package com.smartkids.ai.ui.theme

import androidx.compose.ui.graphics.Color

val Cream = Color(0xFFFFF8E7)
val Ink = Color(0xFF2D2A4A)
val Sunshine = Color(0xFFFFC93C)
val SkyBlue = Color(0xFF4D9BFF)
val Bubblegum = Color(0xFFFF6FA5)

// One colour per subject, so children learn to recognise them at a glance.
val MathsOrange = Color(0xFFFF8A3D)
val EnglishBlue = Color(0xFF4D9BFF)
val ScienceGreen = Color(0xFF2FBF71)
val MarathiPurple = Color(0xFF9B6BFF)
