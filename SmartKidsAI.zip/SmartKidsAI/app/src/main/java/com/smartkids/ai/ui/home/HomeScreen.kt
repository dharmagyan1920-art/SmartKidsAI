package com.smartkids.ai.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smartkids.ai.R
import com.smartkids.ai.model.Subject
import com.smartkids.ai.ui.theme.Bubblegum
import com.smartkids.ai.ui.theme.SmartKidsTheme
import com.smartkids.ai.ui.theme.Sunshine

@Composable
fun HomeScreen(
    onSubjectClick: (Subject) -> Unit,
    onGamesClick: () -> Unit,
    onTutorClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .safeDrawingPadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item { GreetingHeader() }

        item { SectionTitle(stringResource(R.string.home_section_subjects)) }
        items(Subject.entries.chunked(2)) { rowSubjects ->
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                rowSubjects.forEach { subject ->
                    SubjectCard(
                        subject = subject,
                        onClick = { onSubjectClick(subject) },
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }

        item { SectionTitle(stringResource(R.string.home_section_play)) }
        item {
            FeatureCard(
                emoji = "🎮",
                title = stringResource(R.string.games_title),
                tagline = stringResource(R.string.games_tagline),
                color = Bubblegum,
                onClick = onGamesClick,
            )
        }
        item {
            FeatureCard(
                emoji = "🦉",
                title = stringResource(R.string.tutor_title),
                tagline = stringResource(R.string.tutor_tagline),
                color = Sunshine,
                contentColor = MaterialTheme.colorScheme.onBackground,
                onClick = onTutorClick,
            )
        }
    }
}

@Composable
private fun GreetingHeader(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = stringResource(R.string.home_greeting),
                style = MaterialTheme.typography.headlineLarge,
            )
            Text(
                text = stringResource(R.string.home_greeting_sub),
                style = MaterialTheme.typography.titleMedium,
            )
        }
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(Sunshine),
            contentAlignment = Alignment.Center,
        ) {
            Text(text = "🦉", fontSize = 40.sp)
        }
    }
}

@Composable
private fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text = text, style = MaterialTheme.typography.titleLarge, modifier = modifier)
}

@Composable
private fun SubjectCard(
    subject: Subject,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        onClick = onClick,
        modifier = modifier.aspectRatio(1f),
        colors = CardDefaults.cardColors(containerColor = subject.color, contentColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text(text = subject.emoji, fontSize = 52.sp)
            Text(text = stringResource(subject.titleRes), style = MaterialTheme.typography.titleLarge)
            Text(text = stringResource(subject.taglineRes), style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun FeatureCard(
    emoji: String,
    title: String,
    tagline: String,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    contentColor: Color = Color.White,
) {
    Card(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = color, contentColor = contentColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
    ) {
        Row(
            modifier = Modifier.padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(text = emoji, fontSize = 48.sp)
            Column {
                Text(text = title, style = MaterialTheme.typography.titleLarge)
                Text(text = tagline, style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
}

@Preview(showBackground = true, heightDp = 800)
@Composable
private fun HomeScreenPreview() {
    SmartKidsTheme {
        HomeScreen(onSubjectClick = {}, onGamesClick = {}, onTutorClick = {})
    }
}
